﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoMate
{
    class Program
    {//Asignación variables  globales para el conteo de lo que nos pide los reportes
        static int facturasTotal;
        static int CantJugoNaranja, CantLitroLeche, CantCajaCereal, CantCajaGalletas, CantPan;
        static int productosvendidos;
        static int TpuntosGenerados;
        static double TotalVentas;
        static void Main(string[] args)
        {
            
            int opcion = 0;
            
                do
            //INGRESAMOS AL BUCLE PARA INGRESAR A OPCIONES
            {
                Console.WriteLine("---------MENU---------");
                Console.WriteLine("     1. Factura       ");
                Console.WriteLine("     2. Reportes      ");
                Console.WriteLine("     3. Cerrar        ");
                Console.WriteLine("------------------");
                Console.WriteLine("Ingrese la opcion: ");

                // VALIDAMOS SI EXISTE LA OPCIÓN EXISTE INGRESADO
                try
                {
                        opcion = int.Parse(Console.ReadLine());
                        if (opcion <= 3 & opcion > 0)
                    {//SELECCIONAMOS LA OPCIÓN 
                        switch (opcion)
                            {
                                case 1:
                                    facturacion();
                                    break;
                                case 2:
                                    reportes();
                                    break;
                                case 3:
                                    cerrar();
                                    break;
                                default:
                                    Console.WriteLine("Ingreso el valor mal");
                                    break;
                            }
                        }
                        else { Console.WriteLine("Ingresar solo los valores del Menu"); }
                    }
                    catch (Exception)
                    {

                    Console.WriteLine("Caracter inválido");
                }
               

            } while (opcion != 3);
           

        }
        private static void cerrar()
        {
            Environment.Exit(1);
        }
        private static void reportes()
        {//ASIGNAMOS PARA QUE SE MUESTREN LOS VALORES EN PANTALLA 
            Console.WriteLine("Total de facturas realizadas   "+facturasTotal);
            Console.WriteLine("");
            Console.WriteLine(" _____________________DetalleProductos____________________");
            Console.WriteLine("");
            Console.WriteLine("001 | Pan Sándwic| cantidad " + CantPan + "  |total en dinero  "+ (CantPan * 20.99));
            Console.WriteLine("002 | Litro de Leche| cantidad " + CantLitroLeche + "  |total en dinero  " + (CantLitroLeche * 12.99));
            Console.WriteLine("003 | Caja de Galletas| cantidad " + CantCajaGalletas + "  |total en dinero  " + (CantCajaGalletas * 7.99));
            Console.WriteLine("004 | Caja de Cereal| cantidad " + CantCajaCereal + "  |total en dinero  " + (CantCajaCereal * 35.49));
            Console.WriteLine("005 | Litro de jugo de naranja | cantidad " + CantJugoNaranja + "  |total en dinero  " + (CantJugoNaranja * 17.99));
            Console.WriteLine("");
            Console.WriteLine(" _________________________________________________");
            Console.WriteLine("");
            Console.WriteLine("Total de productos vendidos  " + productosvendidos);
            Console.WriteLine("");
            Console.WriteLine(" _________________________________________________");
            Console.WriteLine("");
            Console.WriteLine("Total de puntos  generados   " + TpuntosGenerados);
            Console.WriteLine("");
            Console.WriteLine(" _________________________________________________");
            Console.WriteLine("");
            Console.WriteLine("Total de ventas   " + TotalVentas);
            Console.WriteLine("");
            Console.WriteLine(" _________________________________________________");
            Console.WriteLine("");
        }

        private static void facturacion()
        {
            try
            {
                int Telefono;
                String correo, nombre, nit, fecha, pago;
                Console.WriteLine("-----------------");
                Console.WriteLine("Ingrese Correo");
                correo = Console.ReadLine();
                Console.WriteLine("-----------------");
                Console.WriteLine("Ingrese Nombre");
                nombre = Console.ReadLine();
                Console.WriteLine("-----------------");
                Console.WriteLine("Ingrese Nit");
                nit = Console.ReadLine();
                Console.WriteLine("-----------------");
                Console.WriteLine("Ingrese Telefono");
                Telefono = int.Parse(Console.ReadLine());
                Console.WriteLine("-----------------");
                Console.WriteLine("Ingrese FECHA");
                fecha = Console.ReadLine();
                Console.WriteLine("");
                Console.WriteLine("--------Productos------");
                Console.WriteLine("001,Pan sándwich,20.99");
                Console.WriteLine("002,Litro de leche,12.99");
                Console.WriteLine("003,Caja de galletas,7.99");
                Console.WriteLine("004,Caja de cereal,35.49");
                Console.WriteLine("005,Litro de jugo de naranja,17.99");
                Console.WriteLine("-----------------");
                Console.WriteLine("");
                String descripcion, codigo, opcion = "";
                double subPuntos = 0;
                double subtotal = 0;
                double total = 0;
                double totalDesc = 0;
                int TotalProduc = 0;
                int NOfactura = 0;
                int ingresoPuntos = 0;
                int puntosAcumulados = 0;
                int finalpuntos = 0;
                // INICIALIZAMOS LAS VARIABLES Y LAS PONEMOS NULAS
                String cadena1 = null, cadena2 = null, cadena3 = null, cadena4 = null, cadena5 = null;

                do
                {
                Numero1:
                    Console.WriteLine("INGRESE EL CODIGO DE PRODUCTO: ");
                    codigo = Console.ReadLine();
                    
                    //INGRESAMOS AL BUCLE PARA COMPRAR PRODUCTOS

                    // VALIDAMOS SI EXISTE EL CODIGO INGRESADO
                    if (codigo.Equals("001") || codigo.Equals("002") || codigo.Equals("003") || codigo.Equals("004") || codigo.Equals("005"))
                    {
                        Console.WriteLine("Ingresar Cantidad de Producto: ");
                        int cantidad = int.Parse(Console.ReadLine());
                        //SELECCIONAMOS POR MEDIO DEL CODIGO EL PRODUCTO A COMPRAR 
                        switch (codigo)
                        {
                            case "001":
                                descripcion = "Pan sándwich";
                                CantPan += cantidad;
                                productosvendidos += cantidad;
                                subtotal += cantidad * (20.99);
                                subPuntos += subtotal / (10);
                                cadena1 = ("|" + codigo + "     |" + cantidad + "       |" + "" + descripcion + "    |" + subtotal);

                                break;
                            case "002":
                                descripcion = "Litro de leche";
                                CantLitroLeche += cantidad;
                                productosvendidos += cantidad;
                                subtotal += cantidad * (12.99);
                                subPuntos += subtotal / (10);
                                cadena2 = ("|" + codigo + "     |" + cantidad + "       |" + "" + descripcion + "    |" + subtotal);
                                break;

                            case "003":
                                descripcion = "Caja de Galletas";
                                CantCajaGalletas += cantidad;
                                productosvendidos += cantidad;
                                subtotal += cantidad * (7.99);
                                subPuntos += subtotal / (10);
                                cadena3 = ("|" + codigo + "     |" + cantidad + "       |" + "" + descripcion + "    |" + subtotal);
                                break;

                            case "004":
                                descripcion = "Caja de Cereal";
                                CantCajaCereal += cantidad;
                                productosvendidos += cantidad;
                                subtotal += cantidad * (35.49);
                                subPuntos += subtotal / (10);
                                cadena4 = ("|" + codigo + "     |" + cantidad + "       |" + "" + descripcion + "    |" + subtotal);
                                break;

                            case "005":
                                descripcion = "Litro de jugo de naranja";
                                CantJugoNaranja += cantidad;
                                productosvendidos += cantidad;
                                subtotal += cantidad * (17.99);
                                subPuntos += subtotal / (10);
                                cadena5 = ("|" + codigo + "     |" + cantidad + "       |" + "" + descripcion + "    |" + subtotal);
                                break;

                            default:
                                Console.WriteLine("Codigo incorrecto");
                                break;
                        }
                        total += subtotal;
                        //SE HACE LA SUMA DEL CALCULO DE PUNTOS GENERADOS EN CADA PRODUCTO
                        finalpuntos += Convert.ToInt32(subPuntos);
                        //TOTAL DE VENTAS SERÁ LA SUMA DE TODOS LOS SUBTOTALES
                        TotalVentas += subtotal;
                        Random rdn = new Random();
                        //SE CREO LA FACTURA CON El NUMERO RAMDON CON LA OPCION NEW RAMDDON
                        NOfactura = ((((rdn.Next(1, 1000)) * (finalpuntos * 2)) + (2021 * TotalProduc)) % (1000));
                        if (NOfactura < 1000)
                        {
                            NOfactura = NOfactura * 100;
                                }

                        Console.Write("Desea ingresar otro producto S/N:  ");
                        opcion = Console.ReadLine();
                        

                            Console.ReadKey();
                        if (opcion.Equals("N") || opcion.Equals("n") || opcion.Equals("S") || opcion.Equals("s"))
                        {
                            Console.WriteLine("");
                            Console.WriteLine("");
                        }
                        else
                        {
                            Console.WriteLine("No es una opcion valida, por lo tanto se tomara como un no");
                            Console.WriteLine("");
                        }

                    }
                    else { Console.WriteLine("El codigo no existe ");
                       goto Numero1;
                    }


                    //SE ASIGNA QUE SI SE INGRESA S EL BUCLE REGRESE PARA INGRESAR OTRO PRODUCTO 
                } while (opcion.Equals("S") || opcion.Equals("s")); 




                Console.WriteLine("-----------------");
                Console.WriteLine("Desea pagar con tarjeta o efectivo");
                //SE LE ASIGNA QUE PAGO TOME EL VALOR DE LO INGRESADO, SI NI ES NINGUN METODO TOMARÁ EL VALOR DE EFECTIVO
                pago = Console.ReadLine();

                if (pago.Equals("Efectivo") || pago.Equals("efectivo") || pago.Equals("Tarjeta") || pago.Equals("tarjeta"))
                {
                    
                        Console.WriteLine("Su pago será en "+pago);
                    Console.WriteLine("");
                    pago = Console.ReadLine();
                }
                else
                {
                    Console.WriteLine("El metodo de pago no esta en nuestro sistema, por ello se cobrará en efectivo");
                    Console.WriteLine("");
                    pago ="Efectivo";
                }

                
                Console.Write("Tiene puntos? SI/No: (S/N) ");
                opcion = Console.ReadLine();
                Console.ReadKey();

                if (opcion.Equals("S") || opcion.Equals("s"))
                {
                    string opcion2 = "";
                    //INGRESO DE PUNTOS ACUMULADOS
                    Console.WriteLine("Ingrese puntos");
                    ingresoPuntos = Convert.ToInt32(Console.ReadLine());

                    Console.Write("Desea realizar descuento? SI/No:   ");
                    opcion2 = Console.ReadLine();
                    Console.ReadKey();

                    if (opcion2.Equals("Si") || opcion2.Equals("si"))
                    {//REALIZACIÓN DEL DESCUENTO SI SE TIENE PUNTOS
                        totalDesc = total - ((ingresoPuntos) / 10);
                    }

                    else if (opcion2.Equals("No") || opcion2.Equals("no"))
                    {//ACUMULACIÓN DE LOS PUNTOS PORQUE NO SE QUISO DESCUENTO
                        puntosAcumulados = finalpuntos + ingresoPuntos;
                        totalDesc = total;
                    }
                    else
                    {
                        puntosAcumulados = finalpuntos + ingresoPuntos;
                        totalDesc = total;
                        Console.WriteLine("Ingresó una opcion no valida, por lo tanto se tomara como un no");
                    }
                }
               else if (opcion.Equals("N") || opcion.Equals("n"))
                {
                        Console.WriteLine("Seguimos a realizar su factura");
                        totalDesc = total;
                }
                   else
                {
                    Console.WriteLine("Ingresó una opcion no valida, por lo tanto se tomara como un no");
                    totalDesc = total;
                }


                Console.WriteLine(" _____________________________________________");
                Console.WriteLine("|                                            |");
                Console.WriteLine(" _______________________________" + fecha + "____");
                Console.WriteLine("|------------SUPERMECADO PUBLICMART----------|");
                Console.WriteLine("|Correo: "+correo + "|Nit: " + nit + "|");
                Console.WriteLine("|                                            |");
                Console.WriteLine("|Telefono: " + Telefono + "|Nombre: " + nombre + "|");
                Console.WriteLine("|                                            |");
                Console.WriteLine("|__________________ " + pago + " __________________|");
                Console.WriteLine("|____________________NO.FACTURA " + NOfactura + "______|");
                Console.WriteLine("|                                            |");
                Console.WriteLine("-------------------Factura--------------------");
                Console.WriteLine("|                                            |");
                Console.WriteLine("| CODIGO | CANTIDAD| DESCRIPCION     | PRECIO| ");
                //HACE QUE LAS CADENAS SE MUESTREN EN PANTALLA
                if (cadena1 != null)
                { Console.WriteLine(cadena1); }

                if (cadena2 != null)
                { Console.WriteLine(cadena2); }

                if (cadena3 != null)
                { Console.WriteLine(cadena3); }

                if (cadena4 != null)
                { Console.WriteLine(cadena4); }

                if (cadena5 != null)
                { Console.WriteLine(cadena5); }

                Console.WriteLine("|                                            |");
                Console.WriteLine("------------TOTAL SIN DESCUENTO-----" + total);
                Console.WriteLine("|                                            |");
                Console.WriteLine("|                                            |");
                Console.WriteLine("------------TOTAL CON DESCUENTO-----" + totalDesc);
                Console.WriteLine("|                                            |");
                Console.WriteLine("|                                            |");
                Console.WriteLine("-------TOTAL  puntos generados-----" + finalpuntos);
                Console.WriteLine("|                                            |");
                Console.WriteLine("-------TOTAL  de puntos acumulados----" + puntosAcumulados);
                Console.WriteLine("|                                            |");
                Console.WriteLine("|                                            |");
                Console.WriteLine("|                                            |");
                Console.WriteLine("|                                            |");
                Console.WriteLine("Una copia de la factura se enviará al correo: " + correo);
                Console.WriteLine("|                                            |");
                Console.WriteLine(" _____________________________________________");
                Console.WriteLine("");
                //SE ACUMULAN LAS FACTURAS
                facturasTotal++;
                //SE ACUMULAN LOS PUNTOS QUE SE GENERARON 
                TpuntosGenerados += finalpuntos;

            }
            catch (Exception)
            {
                Console.WriteLine("Cometio errores al ingresar datos");
            }
        }
    }
}
