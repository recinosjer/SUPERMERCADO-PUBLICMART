﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoMate
{
    class Program
    {
        static void Main(string[] args)
        {

            int opcion;
            do
            {
                Console.WriteLine("-----MENU---------");
                Console.WriteLine("1. Factura");
                Console.WriteLine("2. Reportes");
                Console.WriteLine("3. Cerrar");
                Console.WriteLine("------------------");
                Console.WriteLine("Ingrese la opcion: ");
                opcion = int.Parse(Console.ReadLine());
                if (opcion <= 3 & opcion > 0)
                {
                    switch (opcion)
                    {
                        case 1:
                            facturacion();
                            break;
                        case 2:
                            reportes();
                            break;
                        case 3:
                            break;
                    }
                }
                else { Console.WriteLine("Ingresar solo los valores del Menu"); }

            } while (opcion != 3);

        }

        private static void reportes()
        {
            throw new NotImplementedException();
        }

        private static void facturacion()
        {

            Console.WriteLine("001,Pan sándwich,20.99");
            Console.WriteLine("002,Litro de leche,12.99");
            Console.WriteLine("003,Caja de galletas,7.99");
            String descripcion, codigo,correo,nombre,nit, opcion = "";
            int Telefono = 0;
            double subtotal = 0;
            double total = 0;
            // INICIALIZAMOS LAS VARIABLES Y LAS PONEMOS NULAS
            String cadena1 = null, cadena2 = null, cadena3 = null;

            do
            {
                Console.WriteLine("Ingrese Correo");
                correo = Console.ReadLine();
                Console.WriteLine("Ingrese Nombre");
                nombre = Console.ReadLine();
                Console.WriteLine("Ingrese Nit");
                nit = Console.ReadLine();
                Console.WriteLine("Ingrese Telefono");
                Telefono = int.Parse(Console.ReadLine());
                Console.WriteLine("INGRESE EL CODIGO DE PRODUCTO: ");
                codigo = Console.ReadLine();

                //INGRESAMOS AL BUCLE PARA COMPRAR PRODUCTOS

                // VALIDAMOS SI EXISTE EL CODIGO INGRESADO
                if (codigo.Equals("001") || codigo.Equals("002") || codigo.Equals("003"))
                {
                    Console.WriteLine("Ingresar Cantidad de Producto: ");
                    int cantidad = int.Parse(Console.ReadLine());
                    //SELECCIONAMOS POR MEDIO DEL CODIGO EL PRODUCTO A COMPRAR 
                    switch (codigo)
                    {
                        case "001":
                            descripcion = "Pan sándwich";
                            subtotal = cantidad * (20.99);
                            cadena1 = ("|" + codigo + "     |" + cantidad + "       |" + "" + descripcion + "    |" + subtotal);

                            break;
                        case "002":
                            descripcion = "Litro de leche";
                            subtotal = cantidad * (12.99);
                            cadena2 = ("|" + codigo + "     |" + cantidad + "       |" + "" + descripcion + "    |" + subtotal);
                            break;

                        case "003":
                            descripcion = "Caja de Galletas";
                            subtotal = cantidad * (7.99);
                            cadena3 = ("|" + codigo + "     |" + cantidad + "       |" + "" + descripcion + "    |" + subtotal);
                            break;

                    }
                    total = total + subtotal;
                    try
                    {
                        Console.Write("Desea ingresar otro producto S/N:  ");
                    opcion = Console.ReadLine();
                    }catch(Exception ex)
                    {
                        Console.WriteLine("No sea pendejo ingrese una letra");
                    }
                    Console.ReadKey();

                }
                else { Console.WriteLine("El codigo no existe "); }


            } while (opcion.Equals("S") || opcion.Equals("s"));
            Console.WriteLine("");
            Console.WriteLine("");

            Console.WriteLine("-----------------Factura--------------------");
            Console.WriteLine("| CODIGO |CANTIDAD| DESCRIPCION     | PRECIO ");
            if (cadena1 != null)
            { Console.WriteLine(cadena1); }

            if (cadena2 != null)
            { Console.WriteLine(cadena2); }

            if (cadena3 != null) { Console.WriteLine(cadena3); }
            Console.WriteLine("------------TOTAL----------" + total);
            Console.WriteLine("");
            Console.WriteLine("");
        }
    }
}
